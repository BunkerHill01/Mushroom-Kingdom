import { Suspense } from 'react';
import MycoNetwork from './components/MycoNetwork';
import DataInput from './components/DataInput';
import { Activity, Dna, Globe, Network } from 'lucide-react';

function App() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-mycelium-black text-white selection:bg-mycelium-cyan selection:text-black">
      {/* Background 3D Network */}
      <div className="fixed inset-0 z-0">
        <Suspense fallback={null}>
          <MycoNetwork />
        </Suspense>
      </div>

      {/* Overlay Gradient */}
      <div className="fixed inset-0 z-0 bg-gradient-to-b from-black/20 via-transparent to-black/80 pointer-events-none" />

      {/* Navigation */}
      <nav className="relative z-20 border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-mycelium-cyan/10 rounded-full flex items-center justify-center border border-mycelium-cyan/50 neon-border">
              <Dna className="w-6 h-6 text-mycelium-cyan" />
            </div>
            <span className="font-display font-bold text-2xl tracking-tight">
              AMORETTI<span className="text-mycelium-cyan">.HEALTH</span>
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Global Map</a>
            <a href="#" className="hover:text-white transition-colors">Species Database</a>
            <a href="#" className="hover:text-white transition-colors">Research</a>
            <button className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-white transition-all">
              Connect Wallet
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 pt-20 pb-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            
            {/* Hero Text */}
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-mycelium-magenta/10 border border-mycelium-magenta/30 text-mycelium-magenta text-xs font-mono tracking-wider">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-mycelium-magenta opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-mycelium-magenta"></span>
                </span>
                LIVE NETWORK STATUS: ACTIVE
              </div>
              
              <h1 className="font-display text-6xl md:text-7xl font-bold leading-tight">
                The Earth's <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-mycelium-cyan to-mycelium-green neon-text">
                  Fungal Internet
                </span>
              </h1>
              
              <p className="text-xl text-gray-400 max-w-lg leading-relaxed">
                Input your mycology data and visualize your connection to the global biological web. Join the decentralized intelligence of the fungal kingdom.
              </p>

              <div className="flex items-center gap-8 pt-4">
                <div className="flex flex-col gap-1">
                  <span className="text-3xl font-display font-bold text-white">2.4M+</span>
                  <span className="text-xs text-gray-500 uppercase tracking-wider">Samples Indexed</span>
                </div>
                <div className="w-px h-12 bg-white/10" />
                <div className="flex flex-col gap-1">
                  <span className="text-3xl font-display font-bold text-white">142</span>
                  <span className="text-xs text-gray-500 uppercase tracking-wider">Countries Live</span>
                </div>
                <div className="w-px h-12 bg-white/10" />
                <div className="flex flex-col gap-1">
                  <span className="text-3xl font-display font-bold text-white">99.9%</span>
                  <span className="text-xs text-gray-500 uppercase tracking-wider">Uptime</span>
                </div>
              </div>
            </div>

            {/* Data Input Module */}
            <DataInput />
          </div>

          {/* Feature Grid */}
          <div className="mt-32 grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Globe,
                title: "Global Phylogenetics",
                desc: "See where your sample fits in the evolutionary tree of life."
              },
              {
                icon: Activity,
                title: "Real-Time Telemetry",
                desc: "Monitor growth rates and environmental conditions live."
              },
              {
                icon: Network,
                title: "Decentralized Data",
                desc: "Your data is encrypted and stored on the mycelial blockchain."
              }
            ].map((feature, i) => (
              <div key={i} className="group p-8 bg-white/5 hover:bg-white/10 border border-white/5 hover:border-mycelium-cyan/30 rounded-2xl transition-all duration-300">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-6 h-6 text-mycelium-cyan" />
                </div>
                <h3 className="text-xl font-display font-bold mb-3 text-white">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
