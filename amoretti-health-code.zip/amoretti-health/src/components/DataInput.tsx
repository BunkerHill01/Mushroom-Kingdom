import { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Database, Network, Search } from 'lucide-react';

export default function DataInput() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);
    setTimeout(() => setIsAnalyzing(false), 3000);
  };

  return (
    <div className="relative z-10 max-w-4xl mx-auto p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-mycelium-dark/80 backdrop-blur-xl border border-mycelium-cyan/20 rounded-2xl p-8 shadow-2xl shadow-mycelium-cyan/10"
      >
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-mycelium-cyan/10 rounded-lg border border-mycelium-cyan/30">
            <Database className="w-6 h-6 text-mycelium-cyan" />
          </div>
          <div>
            <h2 className="text-2xl font-display font-bold text-white">Myco-Link Engine</h2>
            <p className="text-gray-400 text-sm">Connect your fungal data to the global biological web</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-mono text-mycelium-cyan uppercase tracking-wider">Species Name</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                <input 
                  type="text" 
                  placeholder="e.g. Psilocybe cubensis"
                  className="w-full bg-black/50 border border-gray-800 rounded-lg py-2.5 pl-10 pr-4 text-white focus:border-mycelium-cyan focus:ring-1 focus:ring-mycelium-cyan transition-all outline-none"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-mycelium-cyan uppercase tracking-wider">Substrate Type</label>
              <select className="w-full bg-black/50 border border-gray-800 rounded-lg py-2.5 px-4 text-white focus:border-mycelium-cyan focus:ring-1 focus:ring-mycelium-cyan transition-all outline-none appearance-none">
                <option>Hardwood Sawdust</option>
                <option>Grain Spawn</option>
                <option>Coco Coir</option>
                <option>Manure</option>
                <option>Agar</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-mycelium-cyan uppercase tracking-wider">Location Data</label>
              <input 
                type="text" 
                placeholder="GPS Coordinates or Region"
                className="w-full bg-black/50 border border-gray-800 rounded-lg py-2.5 px-4 text-white focus:border-mycelium-cyan focus:ring-1 focus:ring-mycelium-cyan transition-all outline-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-mycelium-cyan uppercase tracking-wider">Sample ID</label>
              <input 
                type="text" 
                placeholder="Auto-generated"
                disabled
                className="w-full bg-black/30 border border-gray-800 rounded-lg py-2.5 px-4 text-gray-500 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-gray-800">
            <div className="flex items-center justify-center w-full">
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-800 border-dashed rounded-lg cursor-pointer bg-black/30 hover:bg-black/50 hover:border-mycelium-magenta/50 transition-all group">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-8 h-8 mb-3 text-gray-500 group-hover:text-mycelium-magenta transition-colors" />
                  <p className="mb-2 text-sm text-gray-400"><span className="font-semibold text-white">Click to upload</span> or drag and drop</p>
                  <p className="text-xs text-gray-500">DNA Sequence (.fasta), Images, or Lab Reports</p>
                </div>
                <input type="file" className="hidden" />
              </label>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full group relative overflow-hidden bg-mycelium-cyan/10 hover:bg-mycelium-cyan/20 border border-mycelium-cyan/50 text-mycelium-cyan font-bold py-4 rounded-lg transition-all duration-300"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              {isAnalyzing ? (
                <>
                  <Network className="w-5 h-5 animate-spin" />
                  ANALYZING NETWORK TOPOLOGY...
                </>
              ) : (
                <>
                  <Network className="w-5 h-5" />
                  INITIATE MYCO-LINK
                </>
              )}
            </span>
            <div className="absolute inset-0 bg-mycelium-cyan/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" />
          </button>
        </form>
      </motion.div>

      {isAnalyzing && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-8 grid grid-cols-3 gap-4"
        >
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-black/50 border border-mycelium-magenta/30 p-4 rounded-lg">
              <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden mb-2">
                <motion.div 
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2, delay: i * 0.2 }}
                  className="h-full bg-mycelium-magenta"
                />
              </div>
              <p className="text-xs font-mono text-mycelium-magenta">PROCESSING NODE {i}0{i}...</p>
            </div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
